#include<stdio.h>
#include<conio.h>
int main(){
    int n ;
    scanf("%d",&n);
    switch(n){
        case 1  : printf("Lower division");break;
        case 2 :  printf("L division");break;
        case 3 :  printf("U division");break;
        case 4 :  printf("U division");break;
        case 5 :  printf("G division");break;
        default : printf("INVALID");

    }
    return 0;
}