#include<stdio.h>
#include<conio.h>
#include<math.h>
int main(){
    int u;
    float c ; 
    printf("Enter the units consumed = ");
    scanf("%d",&u);
    if(u<=100){
        c = 3.36*u;
        printf("The bill amount is = %f",c);
    }
    else if(u<=300){
        c = 100*3.36 + (u-100)*7.34;
         printf("The bill amount is = %f",c);
    }
    else if(u<=500){
        c = (100*3.36)+(200*7.34)+(u-300)*10.37;
         printf("The bill amount is = %f",c);
    }
    else{
        c = (100*3.36)+(200*7.34)+(300*10.37)+(u-500)*11.86;
         printf("The bill amount is = %f",c);
    }
    return 0;
}