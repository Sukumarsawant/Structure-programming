#include<stdio.h>
#include<conio.h>
#include<math.h>
int main(){
    //gross salary = basic pay + 0.25(basicpay) i.e HRA + other perks .
    int l,s,gs,ns,p; //l - level and s-salary and p-perks
    printf("Enter level number = ");
    scanf("%d",&l);
    printf("Enter basic pay = ");
    scanf("%d",&s);
    if(l ==1){
        p = 1500;
    }
    else if(l==2){
        p=950;
    }
    else if(l==3){
        p=600;
    }
    else {
        p=250;
    }
    gs = s + p + (0.25)*s;
    if(gs<=2000){
        ns = gs;
        printf("Net salary is = %d",ns);
    }
    else if(gs<=4000 && gs>2000){
        ns = gs-(0.03)*gs;
        printf("Net salary is = %d ",ns);
    }
    else if(gs<=5000 && gs>4000){
        ns = gs - (0.05)*gs;
        printf("Net salary is = %d ",ns);
    }
    else {
        ns = gs - (0.08)*gs;
        printf("Net salary is = %d ",ns);
    }
    
    
    return 0;

}