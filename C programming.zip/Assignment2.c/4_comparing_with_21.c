#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
int main(){
    int a , b , a1 , b1 ; 
    printf("Give two Integer Values = ");
    scanf("%d%d",&a,&b);
    a1 = 21-a;
    b1 = 21-b ;
    if(a<=21 && b<=21){
        if(a1>b1){
            printf("%d is closest",b);
        }
        else {
            printf("%d is closest",a);
        }
    }
    else if(a>21 && b>21){
         printf("INVLAID INPUT");
    }
    else {
        if(a<21) {
            printf("%d is closest",a);
        }
        else{
            printf("%d is closest",b);
        }
    }
}